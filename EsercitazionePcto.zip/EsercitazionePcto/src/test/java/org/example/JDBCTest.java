package org.example;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.slf4j.impl.StaticLoggerBinder;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.assertEquals;

@Slf4j

public class JDBCTest {

    private static Connection connection;
    private static Properties properties;

    @BeforeAll
    static void openConnection() throws SQLException {
        loadProperties();
        String url = properties.getProperty("database.url");
        String username = properties.getProperty("database.username");
        String password = properties.getProperty("database.password");
        connection = DriverManager.getConnection(url, username, password);
        log.info("Succesfully connected to DB.");
    }
    private static void loadProperties() {
        properties = new Properties();
        try (InputStream input = JDBCTest.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (input == null) {
                log.error("Couldn't find config.properties");
                return;
            }
            properties.load(input);
        } catch (IOException e) {
            log.error("Error loading properties", e);
        }
    }

    @AfterAll
    static void closeConnection() throws SQLException {
        if (connection != null) {
            connection.close();
            log.info("Connection has been closed.");
        }
    }

    @ParameterizedTest
    @CsvFileSource(resources = "/queries.csv", numLinesToSkip = 1)
    void testQuery(String query, String expectedValue) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            resultSet.next();
            String actualValue = resultSet.getString(1);
            assertEquals(expectedValue, actualValue);
            log.info("Expected value is the same as actual value.");
        }
    }
}
